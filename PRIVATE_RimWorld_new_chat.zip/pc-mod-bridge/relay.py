#!/usr/bin/env python3
"""Temporary authenticated relay. Run in the chat workspace, not on the user's PC."""
from __future__ import annotations
import argparse
import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import secrets
import threading
import time
from urllib.parse import parse_qs, urlsplit
import uuid

OPERATIONS = {'ping', 'list_files', 'read_file', 'search_text', 'validate_xml', 'replace', 'create_file', 'audit_mods', 'audit_page'}
MAX_BODY = 262144


class Relay:
    def __init__(self, config, state_path):
        self.config = config
        self.path = Path(state_path)
        self.lock = threading.RLock()
        if self.path.exists():
            self.state = json.loads(self.path.read_text())
        else:
            self.state = {'device': None, 'jobs': {}}
        # A delivered job is never automatically requeued, including after a restart.

    def save(self):
        temporary = self.path.with_suffix('.tmp')
        temporary.parent.mkdir(parents=True, exist_ok=True)
        temporary.write_text(json.dumps(self.state, ensure_ascii=False), encoding='utf-8')
        temporary.replace(self.path)

    def handle(self, method, route, query, body):
        with self.lock:
            if time.time() >= self.config['expires_at']:
                return 410, {'error': 'SESSION_EXPIRED'}
            device = self.state['device']
            jobs = self.state['jobs']
            if method == 'POST' and route == '/device/register':
                identity, root = body.get('device_id'), body.get('root')
                if not isinstance(identity, str) or len(identity) > 64 or not isinstance(root, str) or not 1 <= len(root) <= 1000:
                    return 400, {'error': 'INVALID_DEVICE'}
                if device and (device['device_id'] != identity or device['root'] != root):
                    return 409, {'error': 'ANOTHER_DEVICE_OR_ROOT_IS_ALREADY_PAIRED'}
                self.state['device'] = {'device_id': identity, 'root': root, 'os': str(body.get('os', ''))[:30],
                                        'agent_version': str(body.get('agent_version', ''))[:30], 'last_seen': time.time()}
                self.save()
                print('Device registered.', flush=True)
                return 200, {'ok': True}
            if route.startswith('/device/'):
                identity = query.get('device_id', [''])[0] if method == 'GET' else body.get('device_id')
                if not device or identity != device['device_id']:
                    return 403, {'error': 'DEVICE_NOT_PAIRED'}
                device['last_seen'] = time.time()
                if method == 'GET' and route == '/device/next':
                    for job in jobs.values():
                        if job['status'] == 'queued':
                            if job['expires_at'] <= time.time():
                                job['status'] = 'expired'
                                continue
                            job['status'] = 'delivered'
                            self.save()
                            return 200, {'job': {k: job[k] for k in ('id', 'operation', 'args', 'expires_at')}}
                    return 200, {'job': None}
                if method == 'POST' and route == '/device/result':
                    job = jobs.get(body.get('job_id'))
                    result = body.get('result')
                    if not job or not isinstance(result, dict):
                        return 400, {'error': 'INVALID_RESULT'}
                    if job['status'] == 'done':
                        # Delivery retries cannot change an already accepted result.
                        return (200, {'ok': True}) if job['result'] == result else (409, {'error': 'RESULT_ALREADY_ACCEPTED'})
                    if job['status'] != 'delivered':
                        return 409, {'error': 'JOB_NOT_DELIVERED'}
                    job['status'], job['result'] = 'done', result
                    self.save()
                    print('Job completed:', job['id'], job['operation'], flush=True)
                    return 200, {'ok': True}
            if method == 'GET' and route == '/operator/status':
                return 200, {'session_id': self.config['session_id'], 'expires_at': self.config['expires_at'],
                             'device': device, 'jobs': [{k: j[k] for k in ('id', 'operation', 'status', 'expires_at')} for j in jobs.values()]}
            if method == 'GET' and route.startswith('/operator/jobs/'):
                job = jobs.get(route.rsplit('/', 1)[-1])
                return (200, job) if job else (404, {'error': 'NOT_FOUND'})
            if method == 'POST' and route == '/operator/jobs':
                if not device:
                    return 409, {'error': 'WAIT_FOR_DEVICE_REGISTRATION'}
                operation, args = body.get('operation'), body.get('args', {})
                if operation not in OPERATIONS or not isinstance(args, dict):
                    return 400, {'error': 'OPERATION_NOT_ALLOWED'}
                if len(jobs) >= 64:
                    removable = next((key for key, job in jobs.items() if job['status'] in {'done', 'expired'}), None)
                    if removable is None:
                        return 429, {'error': 'QUEUE_FULL'}
                    del jobs[removable]
                job_id = uuid.uuid4().hex
                jobs[job_id] = {'id': job_id, 'operation': operation, 'args': args, 'status': 'queued',
                                'expires_at': min(time.time() + 900, self.config['expires_at'])}
                self.save()
                return 201, {'id': job_id, 'status': 'queued'}
            return 404, {'error': 'NOT_FOUND'}


def handler_for(relay):
    class Handler(BaseHTTPRequestHandler):
        def setup(self):
            super().setup()
            self.connection.settimeout(10)

        def log_message(self, format, *args):
            # No request bodies, tokens or file contents in the process log.
            pass

        def send(self, code, payload, html=False):
            data = payload.encode('utf-8') if html else json.dumps(payload, ensure_ascii=False).encode('utf-8')
            self.send_response(code)
            self.send_header('Content-Type', 'text/html; charset=utf-8' if html else 'application/json; charset=utf-8')
            self.send_header('Content-Length', str(len(data)))
            self.send_header('Cache-Control', 'no-store')
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.end_headers()
            self.wfile.write(data)

        def dispatch(self, method):
            if len(self.path) > 2048:
                return self.send(414, {'error': 'URL_TOO_LONG'})
            parsed = urlsplit(self.path)
            if method == 'GET' and parsed.path == '/':
                return self.send(200, '<!doctype html><html lang="ru"><meta charset="utf-8"><title>PC Mod Bridge</title><body style="font:17px system-ui;background:#101724;color:#e4ecf7;padding:40px;max-width:750px;margin:auto"><h1>PC Mod Bridge</h1><p>Временный мост для выбранной папки RimWorld-мода.</p><p>На ПК запускается agent.py из выданного архива. Открывать порт на ПК не нужно. Чтение — только после подключения, каждая запись — после локального подтверждения.</p><p>Эта публичная страница не показывает файлы и не позволяет отправлять задания. API требует отдельные ключи устройства и оператора.</p><p>Сессия не является постоянным сервисом. Параметры подключения находятся в приватном connection.json, не публикуйте его.</p></body></html>', html=True)
            role = 'operator_token' if parsed.path.startswith('/operator/') else 'device_token' if parsed.path.startswith('/device/') else None
            if role is None:
                return self.send(404, {'error': 'NOT_FOUND'})
            expected = 'Bearer ' + relay.config[role]
            received = self.headers.get('Authorization', '')
            if not secrets.compare_digest(received.encode('utf-8'), expected.encode('utf-8')):
                return self.send(401, {'error': 'UNAUTHORIZED'})
            body = {}
            if method == 'POST':
                try:
                    length = int(self.headers.get('Content-Length', '0'))
                    if not 0 < length <= MAX_BODY:
                        return self.send(413, {'error': 'BODY_SIZE'})
                    body = json.loads(self.rfile.read(length))
                    if not isinstance(body, dict):
                        return self.send(400, {'error': 'INVALID_JSON'})
                except (ValueError, TimeoutError):
                    return self.send(400, {'error': 'INVALID_JSON'})
            try:
                code, response = relay.handle(method, parsed.path, parse_qs(parsed.query), body)
                self.send(code, response)
            except (TypeError, ValueError):
                self.send(400, {'error': 'INVALID_ARGUMENTS'})
            except Exception as exc:
                print('Relay error:', type(exc).__name__, flush=True)
                self.send(500, {'error': 'INTERNAL_ERROR'})

        def do_GET(self):
            self.dispatch('GET')

        def do_POST(self):
            self.dispatch('POST')
    return Handler


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', required=True)
    parser.add_argument('--state', required=True)
    parser.add_argument('--port', type=int, default=8787)
    args = parser.parse_args()
    relay = Relay(json.loads(Path(args.config).read_text()), args.state)
    server = ThreadingHTTPServer(('0.0.0.0', args.port), handler_for(relay))
    server.daemon_threads = True
    print(f'PC Mod Bridge relay listening on 0.0.0.0:{args.port}; authentication required.', flush=True)
    server.serve_forever()
