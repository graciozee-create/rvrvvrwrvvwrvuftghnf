"""Offline tests: no external internet or real mod files required."""
import json
from pathlib import Path
import secrets
import tempfile
import threading
import time
import unittest
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer

from agent import Connection
from local_tools import ModTools, ToolError, sha
from relay import Relay, handler_for


class ToolTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.base = Path(temporary.name)
        self.root = self.base / 'Mod'
        self.root.mkdir()
        (self.root / 'Defs').mkdir()
        (self.root / 'Source').mkdir()
        (self.root / 'Defs' / 'Item.xml').write_bytes(b'<Defs>\r\n  <ThingDef><defName>TestItem</defName><value>10</value></ThingDef>\r\n</Defs>\r\n')
        (self.root / 'Source' / 'Demo.cs').write_text('class Demo { int value = 10; }', encoding='utf-8')
        self.tools = ModTools(self.root, self.base / 'Backups', lambda title, preview: True)

    def test_list_is_relative_and_scoped(self):
        (self.root / '.env').write_text('SECRET')
        (self.root / 'bad.dll').write_bytes(b'BINARY')
        result = self.tools.list_files({})
        self.assertEqual({x['path'] for x in result['files']}, {'Defs/Item.xml', 'Source/Demo.cs'})

    def test_path_traversal_windows_and_hidden_paths(self):
        paths = ['../secret.txt', '/tmp/test.txt', 'C:\\Users\\test.txt', '\\\\host\\share\\file.txt',
                 'Defs/Item.xml:secret', '.env', '.git/config.txt', 'Defs/CON.txt', 'Defs/Item.xml.',
                 'Defs/../Source/Demo.cs', 'Defs//Item.xml', 'Defs/file.exe']
        for path in paths:
            with self.subTest(path=path), self.assertRaises((ToolError, OSError)):
                self.tools.path(path, new=True)

    def test_symlink_escape_blocked(self):
        outside = self.base / 'private.txt'
        outside.write_text('SECRET')
        try:
            (self.root / 'linked.txt').symlink_to(outside)
        except OSError:
            self.skipTest('Symlink creation unavailable without privileges')
        with self.assertRaises(ToolError):
            self.tools.read_file({'path': 'linked.txt'})

    def test_read_returns_hash_and_bounded_context(self):
        result = self.tools.read_file({'path': 'Defs/Item.xml', 'line_count': 1})
        self.assertEqual(result['text'], '<Defs>')
        self.assertTrue(result['truncated'])
        self.assertEqual(result['sha256'], sha((self.root / 'Defs/Item.xml').read_bytes()))

    def test_search_is_literal(self):
        result = self.tools.search_text({'query': 'TestItem'})
        self.assertEqual(result['matches'][0]['path'], 'Defs/Item.xml')
        self.assertEqual(self.tools.search_text({'query': 'Test.*'})['matches'], [])

    def test_bad_limits(self):
        for limit in [0, -1, 201, True]:
            with self.assertRaises(ToolError):
                self.tools.read_file({'path': 'Defs/Item.xml', 'line_count': limit})

    def test_backup_stays_outside_mod(self):
        with self.assertRaises(ToolError):
            ModTools(self.root, self.root / 'Backups', lambda *_: True)

    def patch_args(self):
        return {'path': 'Defs/Item.xml', 'old': '<value>10</value>', 'new': '<value>20</value>',
                'expected_sha256': sha((self.root / 'Defs/Item.xml').read_bytes())}

    def test_replace_preserves_crlf_and_creates_backup(self):
        original = (self.root / 'Defs/Item.xml').read_bytes()
        result = self.tools.replace(self.patch_args())
        self.assertTrue(result['changed'])
        current = (self.root / 'Defs/Item.xml').read_bytes()
        self.assertEqual(current, original.replace(b'<value>10</value>', b'<value>20</value>'))
        self.assertEqual((self.base / 'Backups' / result['backup_id']).read_bytes(), original)

    def test_denied_write_does_nothing(self):
        original = (self.root / 'Defs/Item.xml').read_bytes()
        self.tools.confirm = lambda *_: False
        result = self.tools.replace(self.patch_args())
        self.assertTrue(result['denied_by_user'])
        self.assertEqual((self.root / 'Defs/Item.xml').read_bytes(), original)
        self.assertFalse((self.base / 'Backups').exists())

    def test_stale_hash(self):
        args = self.patch_args()
        args['expected_sha256'] = '0' * 64
        with self.assertRaisesRegex(ToolError, 'STALE_FILE'):
            self.tools.replace(args)

    def test_changed_during_confirmation_is_not_overwritten(self):
        args = self.patch_args()
        def approve(*_):
            (self.root / 'Defs/Item.xml').write_text('<Defs>external edit</Defs>')
            return True
        self.tools.confirm = approve
        with self.assertRaisesRegex(ToolError, 'STALE_FILE'):
            self.tools.replace(args)
        self.assertIn('external edit', (self.root / 'Defs/Item.xml').read_text())

    def test_invalid_xml_not_written(self):
        args = self.patch_args()
        args['new'] = '<value>broken'
        with self.assertRaises(ToolError):
            self.tools.replace(args)

    def test_nonunique_replacement_rejected(self):
        args = self.patch_args()
        args['old'] = 'value'
        with self.assertRaises(ToolError):
            self.tools.replace(args)

    def test_utf8_bom_preserved(self):
        path = self.root / 'Defs/Item.xml'
        path.write_bytes(b'\xef\xbb\xbf' + path.read_bytes())
        self.tools.replace(self.patch_args())
        self.assertTrue(path.read_bytes().startswith(b'\xef\xbb\xbf'))

    def test_no_automatic_recoding(self):
        (self.root / 'other.txt').write_bytes('Привет'.encode('cp1251'))
        with self.assertRaises(ToolError):
            self.tools.read_file({'path': 'other.txt'})

    def test_file_size_bound(self):
        (self.root / 'large.txt').write_bytes(b'x' * (1024 * 1024 + 1))
        with self.assertRaises(ToolError):
            self.tools.read_file({'path': 'large.txt'})

    def test_xml_validation_and_entity_rejection(self):
        self.assertTrue(self.tools.validate_xml({'path': 'Defs/Item.xml'})['xml_well_formed'])
        (self.root / 'bad.xml').write_text('<!DOCTYPE x [<!ENTITY t "boom">]><x>&t;</x>')
        with self.assertRaises(ToolError):
            self.tools.validate_xml({'path': 'bad.xml'})

    def test_create_without_overwrite(self):
        result = self.tools.create_file({'path': 'Source/New.cs', 'content': 'class New {}'})
        self.assertTrue(result['created'])
        with self.assertRaises(ToolError):
            self.tools.create_file({'path': 'Source/New.cs', 'content': 'replace'})

    def test_no_shell_or_delete(self):
        for operation in ['shell', 'powershell', 'delete', 'exec', 'build_project']:
            with self.assertRaises(ToolError):
                self.tools.execute(operation, {})


class RelayTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        self.config = {'session_id': 'test', 'operator_token': secrets.token_urlsafe(32),
                       'device_token': secrets.token_urlsafe(32), 'expires_at': time.time() + 3600}
        self.relay = Relay(self.config, self.root / 'state.json')
        self.http = ThreadingHTTPServer(('127.0.0.1', 0), handler_for(self.relay))
        self.thread = threading.Thread(target=self.http.serve_forever, daemon=True)
        self.thread.start()
        self.addCleanup(self.close)
        self.base = 'http://127.0.0.1:' + str(self.http.server_port)

    def close(self):
        self.http.shutdown()
        self.http.server_close()
        self.thread.join(2)

    def request(self, route, payload=None, role='device'):
        request = urllib.request.Request(self.base + route,
            data=None if payload is None else json.dumps(payload).encode(),
            headers={'Authorization': 'Bearer ' + self.config[role + '_token'], 'Content-Type': 'application/json'})
        with urllib.request.urlopen(request, timeout=5) as response:
            return json.load(response)

    def register(self):
        return self.request('/device/register', {'device_id': 'device-1', 'root': 'C:\\Mod', 'os': 'nt'})

    def submit(self, operation='ping', args=None):
        return self.request('/operator/jobs', {'operation': operation, 'args': args or {}}, role='operator')['id']

    def test_role_separation(self):
        with self.assertRaises(urllib.error.HTTPError) as caught:
            self.request('/operator/jobs', {'operation': 'ping'})
        self.assertEqual(caught.exception.code, 401)
        with self.assertRaises(urllib.error.HTTPError):
            self.request('/device/register', {'device_id': 'x', 'root': 'C:\\Mod'}, role='operator')

    def test_public_page_does_not_expose_tokens_or_paths(self):
        self.register()
        with urllib.request.urlopen(self.base + '/') as response:
            page = response.read().decode()
        self.assertNotIn(self.config['device_token'], page)
        self.assertNotIn(self.config['operator_token'], page)
        self.assertNotIn('C:\\Mod', page)

    def test_registration_is_bound_to_one_root(self):
        self.register()
        with self.assertRaises(urllib.error.HTTPError) as caught:
            self.request('/device/register', {'device_id': 'device-1', 'root': 'C:\\Other'})
        self.assertEqual(caught.exception.code, 409)

    def test_job_is_not_redelivered_and_result_retry_is_idempotent(self):
        self.register()
        job_id = self.submit()
        job = self.request('/device/next?device_id=device-1')['job']
        self.assertEqual(job['id'], job_id)
        self.assertIsNone(self.request('/device/next?device_id=device-1')['job'])
        payload = {'device_id': 'device-1', 'job_id': job_id, 'result': {'ok': True}}
        self.request('/device/result', payload)
        self.request('/device/result', payload)
        result = self.request('/operator/jobs/' + job_id, role='operator')
        self.assertEqual(result['status'], 'done')

    def test_expired_job_not_delivered(self):
        self.register()
        job_id = self.submit()
        self.relay.state['jobs'][job_id]['expires_at'] = time.time() - 1
        self.assertIsNone(self.request('/device/next?device_id=device-1')['job'])

    def test_delivered_state_survives_restart_without_reexecution(self):
        self.register()
        self.submit()
        self.request('/device/next?device_id=device-1')
        restored = Relay(self.config, self.root / 'state.json')
        code, result = restored.handle('GET', '/device/next', {'device_id': ['device-1']}, {})
        self.assertEqual(code, 200)
        self.assertIsNone(result['job'])

    def test_full_read_patch_flow_on_temporary_mod(self):
        self.register()
        mod = self.root / 'Mod'
        mod.mkdir()
        (mod / 'Item.xml').write_text('<Defs><value>10</value></Defs>')
        tools = ModTools(mod, self.root / 'Backups', lambda *_: True)
        read_id = self.submit('read_file', {'path': 'Item.xml'})
        read_job = self.request('/device/next?device_id=device-1')['job']
        read_result = tools.execute(read_job['operation'], read_job['args'])
        self.request('/device/result', {'device_id': 'device-1', 'job_id': read_id, 'result': {'ok': True, 'value': read_result}})
        patch_id = self.submit('replace', {'path': 'Item.xml', 'old': '<value>10</value>', 'new': '<value>20</value>', 'expected_sha256': read_result['sha256']})
        patch_job = self.request('/device/next?device_id=device-1')['job']
        value = tools.execute(patch_job['operation'], patch_job['args'])
        self.request('/device/result', {'device_id': 'device-1', 'job_id': patch_id, 'result': {'ok': True, 'value': value}})
        self.assertIn('<value>20</value>', (mod / 'Item.xml').read_text())
        self.assertTrue(value['backup_created'])


class ConnectionTests(unittest.TestCase):
    def test_insecure_or_credential_url_rejected(self):
        for url in ['http://example.org', 'https://user:pass@example.org', 'https://example.org/?key=x', 'https://example.org/#key']:
            with self.assertRaises(ValueError):
                Connection({'url': url, 'device_token': 'x' * 40})

    def test_https_and_token_required(self):
        Connection({'url': 'https://example.org', 'device_token': 'x' * 40})
        with self.assertRaises(ValueError):
            Connection({'url': 'https://example.org', 'device_token': 'short'})


if __name__ == '__main__':
    unittest.main()
