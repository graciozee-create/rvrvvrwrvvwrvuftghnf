#!/usr/bin/env python3
"""Operator helper for the chat workspace. Operator credentials are NOT shipped to the PC."""
import argparse
import json
from pathlib import Path
import urllib.request
import urllib.error
import urllib.parse


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise urllib.error.HTTPError(req.full_url, code, "Redirect refused for authenticated request", headers, fp)


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--config', default=str(Path(__file__).with_name('.session') / 'operator.json'))
parser.add_argument('--base', default='http://127.0.0.1:8787')
sub = parser.add_subparsers(dest='command', required=True)
sub.add_parser('status')
submit = sub.add_parser('submit')
submit.add_argument('operation')
submit.add_argument('--args', default='{}')
result = sub.add_parser('result')
result.add_argument('job_id')
args = parser.parse_args()
parsed = urllib.parse.urlsplit(args.base)
if parsed.username or parsed.password or parsed.query or parsed.fragment or parsed.path not in {'', '/'}:
    parser.error('Use a server origin without credentials, path, query or fragment')
if parsed.scheme != 'https' and not (parsed.scheme == 'http' and parsed.hostname in {'127.0.0.1', 'localhost', '::1'}):
    parser.error('External connections require HTTPS')
args.base = args.base.rstrip('/')
config = json.loads(Path(args.config).read_text())
route, payload = '/operator/status', None
if args.command == 'submit':
    route, payload = '/operator/jobs', {'operation': args.operation, 'args': json.loads(args.args)}
elif args.command == 'result':
    route = '/operator/jobs/' + args.job_id
request = urllib.request.Request(args.base + route,
    data=None if payload is None else json.dumps(payload, ensure_ascii=False).encode('utf-8'),
    headers={'Authorization': 'Bearer ' + config['operator_token'], 'Content-Type': 'application/json'})
with urllib.request.build_opener(NoRedirect()).open(request, timeout=15) as response:
    print(json.dumps(json.load(response), ensure_ascii=False, indent=2))
