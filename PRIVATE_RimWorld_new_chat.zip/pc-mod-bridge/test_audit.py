import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from agent import confirm
from local_tools import ModTools
from rimworld_audit import RimWorldAudit, selected_rules
import xml.etree.ElementTree as ET


class AuditTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.base = Path(temporary.name)
        self.mods = self.base / 'Game' / 'Mods'
        self.mods.mkdir(parents=True)
        self.profile = self.base / 'Profile'
        (self.profile / 'Config').mkdir(parents=True)
        self.tools = ModTools(self.mods, self.base / 'AppState' / 'backups', lambda *_: self.fail('Audit must not ask to write a mod'))
        self.tools.profile_root = self.profile
        self.tools.allow_game_metadata = True

    def mod(self, folder, key, extra='', versions=('1.6',), base=None):
        base = base or self.mods
        directory = base / folder / 'About'
        directory.mkdir(parents=True)
        xml = '<ModMetaData><name>' + folder + '</name><packageId>' + key + '</packageId><supportedVersions>'
        xml += ''.join('<li>' + v + '</li>' for v in versions) + '</supportedVersions>' + extra + '</ModMetaData>'
        path = directory / 'About.xml'
        path.write_text(xml, encoding='utf-8')
        return path

    def config(self, ids, version='1.6.1234'):
        xml = '<ModsConfigData><version>' + version + '</version><activeMods>'
        xml += ''.join('<li>' + p + '</li>' for p in ids) + '</activeMods></ModsConfigData>'
        (self.profile / 'Config' / 'ModsConfig.xml').write_text(xml)

    def run_audit(self, **args):
        result = RimWorldAudit(self.tools).run(args)
        path = self.base / 'AppState' / 'reports' / (result['report_id'] + '.json')
        return result, json.loads(path.read_text())

    def test_inventory_does_not_use_general_text_walk(self):
        self.mod('A', 'test.a')
        self.config(['test.a'])
        with patch.object(self.tools, 'walk', side_effect=AssertionError('Should not scan every file')):
            result, report = self.run_audit()
        self.assertEqual(result['summary']['mods_in_selected_folder'], 1)
        self.assertFalse(result['summary']['mod_files_changed'])
        self.assertFalse(result['summary']['compatibility_proven'])

    def test_missing_active_dependency(self):
        self.mod('A', 'test.a', '<modDependencies><li><packageId>test.lib</packageId><displayName>Library</displayName></li></modDependencies>')
        self.mod('B', 'test.lib')
        self.config(['test.a'])
        _, report = self.run_audit()
        failure = next(f for f in report['findings'] if f['code'] == 'DEPENDENCY_NOT_ACTIVE')
        self.assertEqual(failure['installed_candidates'], ['test.lib'])

    def test_inactive_mod_dependency_is_not_reported_as_active_error(self):
        self.mod('A', 'test.a', '<modDependencies><li><packageId>test.missing</packageId></li></modDependencies>')
        self.mod('B', 'test.b')
        self.config(['test.b'])
        _, report = self.run_audit()
        self.assertFalse(any(f['code'] == 'DEPENDENCY_NOT_ACTIVE' for f in report['findings']))

    def test_versioned_dependencies_replace_general_list(self):
        self.mod('A', 'test.a', '<modDependencies><li><packageId>test.old</packageId></li></modDependencies><modDependenciesByVersion><v1.6><li><packageId>test.new</packageId></li></v1.6></modDependenciesByVersion>')
        self.mod('New', 'test.new')
        self.config(['test.new', 'test.a'])
        _, report = self.run_audit()
        self.assertFalse(any(f['code'] == 'DEPENDENCY_NOT_ACTIVE' for f in report['findings']))
        row = next(r for r in report['mods'] if r['package_id'] == 'test.a')
        self.assertEqual(row['modDependencies'][0]['package_id'], 'test.new')

    def test_empty_versioned_list_is_an_override(self):
        root = ET.fromstring('<ModMetaData><loadAfter><li>test.b</li></loadAfter><loadAfterByVersion><v1.6 /></loadAfterByVersion></ModMetaData>')
        self.assertEqual(selected_rules(root, 'loadAfter', '1.6')[0], [])

    def test_alternative_dependency_for_16(self):
        self.mod('A', 'test.a', '<modDependencies><li><packageId>test.lib</packageId><alternativePackageIds><li>test.beta</li></alternativePackageIds></li></modDependencies>')
        self.mod('Beta', 'test.beta')
        self.config(['test.beta', 'test.a'])
        _, report = self.run_audit()
        self.assertFalse(any(f['code'] == 'DEPENDENCY_NOT_ACTIVE' for f in report['findings']))

    def test_active_declared_conflict(self):
        self.mod('A', 'test.a', '<incompatibleWith><li>test.b</li></incompatibleWith>')
        self.mod('B', 'test.b')
        self.config(['test.a', 'test.b'])
        _, report = self.run_audit()
        self.assertTrue(any(f['code'] == 'DECLARED_ACTIVE_CONFLICT' and f['severity'] == 'error' for f in report['findings']))

    def test_installed_only_conflict_is_not_active_failure(self):
        self.mod('A', 'test.a', '<incompatibleWith><li>test.b</li></incompatibleWith>')
        self.mod('B', 'test.b')
        self.config(['test.a'])
        _, report = self.run_audit()
        finding = next(f for f in report['findings'] if 'CONFLICT' in f['code'])
        self.assertEqual(finding['code'], 'DECLARED_INSTALLED_CONFLICT')
        self.assertEqual(finding['severity'], 'info')

    def test_load_order_direction(self):
        self.mod('A', 'test.a', '<loadAfter><li>test.b</li></loadAfter>')
        self.mod('B', 'test.b')
        self.config(['test.a', 'test.b'])
        _, report = self.run_audit()
        self.assertTrue(any(f['code'] == 'DECLARED_LOAD_ORDER' for f in report['findings']))
        self.config(['test.b', 'test.a'])
        _, report = self.run_audit()
        self.assertFalse(any(f['code'] == 'DECLARED_LOAD_ORDER' for f in report['findings']))

    def test_duplicate_package_not_assumed_to_be_specific_version(self):
        self.mod('A', 'test.same', versions=('1.4',))
        self.mod('B', 'test.same')
        self.config(['test.same'])
        _, report = self.run_audit()
        self.assertTrue(any(f['code'] == 'DUPLICATE_PACKAGE_ID' for f in report['findings']))
        self.assertFalse(any(f['code'] == 'VERSION_NOT_DECLARED' for f in report['findings']))
        self.assertFalse(report['active_mods'][0]['resolved'])

    def test_missing_profile_does_not_assume_all_mods_active(self):
        self.mod('A', 'test.a')
        self.tools.profile_root = None
        result, report = self.run_audit()
        self.assertFalse(result['summary']['active_list_available'])
        self.assertIsNone(report['mods'][0]['active'])

    def test_game_data_metadata_is_read_only_and_opt_in(self):
        self.mod('Core', 'ludeon.rimworld', base=self.base / 'Game' / 'Data')
        self.config(['ludeon.rimworld'])
        self.tools.allow_game_metadata = False
        result, _ = self.run_audit()
        self.assertEqual(result['summary']['built_in_metadata_count'], 0)
        self.tools.allow_game_metadata = True
        result, _ = self.run_audit()
        self.assertEqual(result['summary']['built_in_metadata_count'], 1)

    def test_xml_error_is_localized(self):
        bad = self.mod('Broken', 'test.bad')
        bad.write_text('<ModMetaData><name>Broken')
        self.mod('Good', 'test.good')
        self.config(['test.good'])
        _, report = self.run_audit()
        self.assertEqual(len(report['mods']), 2)
        self.assertTrue(any(f['code'] == 'INVALID_METADATA_XML' for f in report['findings']))

    def test_log_errors_and_game_version_are_collected(self):
        self.mod('A', 'test.a')
        self.config(['test.a'])
        (self.profile / 'Player.log').write_text('RimWorld 1.6.1234 rev1\nNullReferenceException: test\n  at Test.Run()\n\nNullReferenceException: test\n', encoding='utf-8')
        result, report = self.run_audit()
        self.assertEqual(result['summary']['target_version'], '1.6')
        self.assertEqual(report['log_errors'][0]['occurrences_in_sample'], 2)
        self.assertIn('Test.Run', report['log_errors'][0]['context'])

    def test_mod_and_profile_bytes_are_unchanged(self):
        metadata = self.mod('A', 'test.a')
        self.config(['test.a'])
        config = self.profile / 'Config' / 'ModsConfig.xml'
        old = (metadata.read_bytes(), config.read_bytes())
        self.run_audit()
        self.assertEqual(old, (metadata.read_bytes(), config.read_bytes()))

    def test_report_pagination_and_path_safety(self):
        self.mod('A', 'test.a')
        self.mod('B', 'test.b')
        self.config(['test.a', 'test.b'])
        result, _ = self.run_audit()
        auditor = RimWorldAudit(self.tools)
        first = auditor.page({'report_id': result['report_id'], 'section': 'mods', 'limit': 1})
        self.assertEqual(first['next_offset'], 1)
        with self.assertRaises(ValueError):
            auditor.page({'report_id': '../../private'})

    def test_auto_write_mode_does_not_prompt(self):
        with patch('builtins.input', side_effect=AssertionError('Unexpected prompt')), patch('builtins.print'):
            self.assertTrue(confirm('Test', 'Diff', automatic=True))

    def test_confirm_mode_still_prompts(self):
        with patch('builtins.input', return_value='NO'), patch('builtins.print'):
            self.assertFalse(confirm('Test', 'Diff', automatic=False))


if __name__ == '__main__':
    unittest.main()
