#!/usr/bin/env python3
"""Visible, outbound-only Windows mod executor. No local LLM or pip dependencies."""
from __future__ import annotations

import argparse
import datetime
import json
import os
from pathlib import Path
import sqlite3
import ssl
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid

from local_tools import ModTools, ToolError, safe_display


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise urllib.error.HTTPError(req.full_url, code, 'Redirect refused', headers, fp)


class Connection:
    def __init__(self, config):
        self.base = str(config.get('url', '')).rstrip('/')
        parsed = urllib.parse.urlsplit(self.base)
        if parsed.scheme != 'https' or not parsed.hostname or parsed.username or parsed.password or parsed.query or parsed.fragment or parsed.path not in {'', '/'}:
            raise ValueError('В connection.json нужен HTTPS-адрес сервера без пути, параметров и пароля.')
        self.token = str(config.get('device_token', ''))
        if len(self.token) < 32:
            raise ValueError('Неверный ключ подключения.')
        self.opener = urllib.request.build_opener(NoRedirect(), urllib.request.HTTPSHandler(context=ssl.create_default_context()))

    def request(self, route, payload=None):
        data = None if payload is None else json.dumps(payload, ensure_ascii=False).encode('utf-8')
        request = urllib.request.Request(self.base + route, data=data, headers={
            'Authorization': 'Bearer ' + self.token, 'Content-Type': 'application/json',
            'User-Agent': 'PCModBridge/0.3',
        })
        with self.opener.open(request, timeout=20) as response:
            raw = response.read(262145)
        if len(raw) > 262144:
            raise ValueError('Ответ сервера слишком большой.')
        result = json.loads(raw)
        if not isinstance(result, dict):
            raise ValueError('Некорректный JSON сервера.')
        return result


def acquire_instance_lock(path):
    handle = open(path, 'a+b')
    if handle.tell() == 0:
        handle.write(b'0')
        handle.flush()
    handle.seek(0)
    try:
        if os.name == 'nt':
            import msvcrt
            msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        handle.close()
        raise ValueError('Для этой папки и сессии агент уже запущен.') from None
    return handle


def confirm(title, preview, automatic=False):
    print('\n' + '=' * 60)
    print(safe_display(title))
    print(safe_display(preview))
    print('=' * 60)
    if automatic:
        print('AUTO: запись разрешена локальной настройкой write_policy=auto.')
        return True
    return input('Разрешить запись? Введите YES, иначе Enter для отказа: ').strip() == 'YES'


def register_with_retries(connection, registration, expires_at, budget_seconds=720):
    """CONNECT remains a single explicit consent; the registration request itself
    survives transient tunnel outages (HTTP 530/5xx, network drops) by retrying.
    Fatal rejections (401/403/409/410) are raised immediately, never retried."""
    fatal_codes = {401, 403, 409, 410}
    deadline = min(time.time() + budget_seconds, expires_at)
    attempt = 0
    while True:
        attempt += 1
        try:
            connection.request('/device/register', registration)
            if attempt > 1:
                print('Регистрация удалась с попытки', attempt, '.')
            return
        except urllib.error.HTTPError as exc:
            if exc.code in fatal_codes:
                raise
            problem = 'HTTP ' + str(exc.code)
        except (urllib.error.URLError, TimeoutError, ConnectionError) as exc:
            problem = safe_display(str(getattr(exc, 'reason', exc)))[:120]
        remaining = deadline - time.time()
        if remaining <= 0:
            raise ValueError('Сервер так и не стал доступен за отведённое время; подключение не выполнено. Напишите в чат, чтобы разбудить среду, и повторите запуск.')
        pause = min(30, 5 * attempt)
        print('Регистрация: ' + problem + ' — сервер временно недоступен. Автоповтор через ' + str(pause) + ' с (попытка ' + str(attempt) + ', осталось ~' + str(int(remaining // 60)) + ' мин). Не закрывайте окно.')
        time.sleep(pause)


def run(config_path, root_arg):
    config = json.loads(Path(config_path).read_text(encoding='utf-8-sig'))
    connection = Connection(config)
    expires_at = config.get('expires_at', 0)
    if not isinstance(expires_at, (float, int)) or time.time() >= expires_at:
        raise ValueError('Сессия истекла. Попросите новый connection.json в чате.')
    root = root_arg or config.get('root') or input('Полный путь к папке Mods или рабочей копии мода: ').strip().strip('"')
    write_policy = config.get('write_policy', 'confirm')
    if write_policy not in {'confirm', 'auto'}:
        raise ValueError('write_policy: confirm или auto.')
    auto_writes = write_policy == 'auto'
    state_dir = Path(os.getenv('LOCALAPPDATA', str(Path.home() / '.local' / 'share'))) / 'PCModBridge'
    state_dir.mkdir(parents=True, exist_ok=True)
    tools = ModTools(root, state_dir / 'backups', confirm)
    tools.auto_writes = auto_writes
    tools.allow_game_metadata = config.get('read_game_metadata') is True
    if config.get('read_rimworld_profile') is True:
        default_profile = Path.home() / 'AppData' / 'LocalLow' / 'Ludeon Studios' / 'RimWorld by Ludeon Studios'
        tools.profile_root = Path(config.get('rimworld_profile_path') or default_profile).expanduser().resolve()
    session_id = config.get('session_id')
    if not isinstance(session_id, str) or len(session_id) < 16:
        raise ValueError('В connection.json отсутствует идентификатор сессии.')
    device_id = str(uuid.uuid5(uuid.NAMESPACE_URL, connection.base + '|' + session_id + '|' + str(tools.root)))
    lock_handle = acquire_instance_lock(state_dir / (device_id + '.lock'))
    database = sqlite3.connect(state_dir / (device_id + '.sqlite3'))
    database.execute('CREATE TABLE IF NOT EXISTS receipts (id TEXT PRIMARY KEY, result TEXT NOT NULL, sent INTEGER NOT NULL DEFAULT 0, created REAL NOT NULL)')
    database.commit()

    print('\nPC Mod Bridge 0.3 (сборка r3: shell-доступ + автоповтор регистрации) — нейросеть на ПК НЕ запускается.')
    print('Сервер:', connection.base)
    print('Папка:', safe_display(str(tools.root)))
    print('Автоматически: список, поиск, чтение разрешённых текстовых файлов, проверка XML.')
    print('Записи: АВТОМАТИЧЕСКИ, без YES.' if auto_writes else 'Каждая запись: только после YES.')
    print('SHELL: команды run_shell печатаются в этом окне и пишутся в ' + safe_display(str(state_dir / 'shell.log')) + '.')
    print('SHA256, резервные копии и ограничение каталога остаются включены.')
    if tools.profile_root is not None:
        print('Дополнительно только чтение Config/ModsConfig.xml, Player.log и Player-prev.log из:', safe_display(str(tools.profile_root)))
    if tools.allow_game_metadata:
        print('Для аудита: только чтение метаданных соседних Data/*/About/About.xml и LoadFolders.xml.')
    print('Изменяемые существующие файлы сохраняются в:', safe_display(str(state_dir / 'backups')))
    print('Запрещены произвольные команды, удаление файлов, управление окнами и доступ вне объявленных областей.')
    print('Выдержки из файлов передаются в эту облачную сессию. Не выбирайте папку с секретами.')
    print('Работа без автозапуска; остановить — Ctrl+C или закрыть окно.')
    print('После CONNECT: если сервер временно недоступен (530/обрыв связи), регистрация повторяется автоматически до ~12 минут.')
    print('Сессия действует не позже:', datetime.datetime.fromtimestamp(expires_at).strftime('%Y-%m-%d %H:%M:%S'))
    if input('Разрешить подключение с указанными выше правами? Введите CONNECT: ').strip() != 'CONNECT':
        print('Отменено.')
        database.close()
        lock_handle.close()
        return

    registration = {'device_id': device_id, 'root': str(tools.root), 'os': os.name, 'agent_version': '0.3.0-r3'}
    register_with_retries(connection, registration, expires_at)
    print('\nПодключено. Напишите в чате: «Агент подключён». Оставьте это окно открытым.')
    failures = 0
    try:
        while time.time() < expires_at:
            try:
                # Outbox is on disk, not in RAM. Never execute a job again to retry delivery.
                pending = database.execute('SELECT id, result FROM receipts WHERE sent=0 ORDER BY created LIMIT 1').fetchone()
                if pending:
                    connection.request('/device/result', {'device_id': device_id, 'job_id': pending[0], 'result': json.loads(pending[1])})
                    database.execute('UPDATE receipts SET sent=1 WHERE id=?', (pending[0],))
                    database.execute('DELETE FROM receipts WHERE sent=1 AND id NOT IN (SELECT id FROM receipts ORDER BY created DESC LIMIT 100)')
                    database.commit()
                envelope = connection.request('/device/next?device_id=' + device_id)
                failures = 0
                job = envelope.get('job')
                if job is None:
                    time.sleep(3)
                    continue
                job_id = job.get('id')
                if not isinstance(job_id, str) or len(job_id) > 64:
                    raise ValueError('Некорректный идентификатор задания.')
                previous = database.execute('SELECT result FROM receipts WHERE id=?', (job_id,)).fetchone()
                if previous:
                    connection.request('/device/result', {'device_id': device_id, 'job_id': job_id, 'result': json.loads(previous[0])})
                    continue
                interrupted = {'ok': False, 'error': 'INTERRUPTED: выполнение было прервано; состояние файла нужно проверить заново, не повторять запись вслепую.'}
                database.execute('INSERT INTO receipts VALUES (?, ?, 0, ?)', (job_id, json.dumps(interrupted), time.time()))
                database.commit()
                operation, args = job.get('operation'), job.get('args', {})
                print('\nЗадание:', safe_display(str(operation)), safe_display(str(args.get('path', ''))) if isinstance(args, dict) else '')
                try:
                    if not isinstance(job.get('expires_at'), (int, float)) or time.time() >= job['expires_at']:
                        raise ToolError('Задание истекло; не выполнено.')
                    def approved_before_expiry(title, preview):
                        approved = confirm(title, preview, automatic=auto_writes)
                        if time.time() >= min(job['expires_at'], expires_at):
                            print('Задание/сессия истекли во время подтверждения. Запись отменена.')
                            return False
                        return approved
                    tools.confirm = approved_before_expiry
                    value = tools.execute(operation, args)
                    result = {'ok': True, 'value': value}
                except (ToolError, OSError, ValueError, TypeError, RuntimeError) as exc:
                    result = {'ok': False, 'error': safe_display(str(exc))[:2000]}
                serialized = json.dumps(result, ensure_ascii=False)
                if len(serialized.encode('utf-8')) > 200000:
                    result = {'ok': False, 'error': 'Результат слишком большой; уменьшите запрос.'}
                    serialized = json.dumps(result, ensure_ascii=False)
                database.execute('UPDATE receipts SET result=? WHERE id=?', (serialized, job_id))
                database.commit()
                print('Готово.' if result['ok'] else 'Ошибка: ' + result['error'])
            except urllib.error.HTTPError as exc:
                if exc.code in {401, 403, 409, 410}:
                    print('Подключение отклонено/истекло (HTTP', exc.code, '). Попросите в чате новые параметры подключения.')
                    break
                failures += 1
                print('HTTP-ошибка связи:', exc.code)
                if failures >= 8:
                    break
                time.sleep(min(30, 3 * failures))
            except (urllib.error.URLError, TimeoutError, ConnectionError) as exc:
                failures += 1
                print('Связь временно отсутствует. Попытка', failures, 'из 8.')
                if failures >= 8:
                    print('Остановлено. Среда чата могла завершиться; запросите новый connection.json.')
                    break
                time.sleep(min(30, 3 * failures))
    except KeyboardInterrupt:
        print('\nАгент остановлен пользователем.')
    finally:
        database.close()
        lock_handle.close()
    print('Соединение закрыто. Команды больше не выполняются.')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', default=str(Path(__file__).with_name('connection.json')))
    parser.add_argument('--root', help='One mod folder; asked interactively when omitted.')
    args = parser.parse_args()
    try:
        run(args.config, args.root)
    except KeyboardInterrupt:
        print('\nОстановлено.')
    except Exception as exc:
        print('Не удалось продолжить:', safe_display(str(exc))[:2000])
        raise SystemExit(1)
