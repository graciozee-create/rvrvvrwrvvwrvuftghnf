"""Read-only RimWorld metadata/profile audit. No mod changes, game launch or LLM."""
from __future__ import annotations
from collections import Counter, defaultdict
import datetime as dt
import json
import itertools
import os
from pathlib import Path
import re
import time
import uuid
import xml.etree.ElementTree as ET

MAX_XML = 1024 * 1024
MAX_MODS = 1500
MAX_FINDINGS = 4000
RULES = ('modDependencies', 'loadBefore', 'loadAfter', 'forceLoadBefore', 'forceLoadAfter', 'incompatibleWith')


def short(value, limit=1200):
    return ' '.join(str(value or '').split())[:limit]


def pid(value):
    return str(value or '').strip().lower()


def utc(timestamp):
    return dt.datetime.fromtimestamp(timestamp, dt.timezone.utc).isoformat()


def minor(value):
    found = re.search(r'(?<!\d)(\d+\.\d+)', str(value or ''))
    return found.group(1) if found else None


def safe_file(path: Path, base: Path) -> Path:
    base = base.resolve()
    current = path
    while current != base and base in current.parents:
        if current.is_symlink() or (hasattr(current, 'is_junction') and current.is_junction()):
            raise ValueError('Symlink/junction skipped')
        current = current.parent
    resolved = path.resolve(strict=True)
    if base not in resolved.parents or not resolved.is_file():
        raise ValueError('Outside read-only scope or not a file')
    return resolved


def read_xml(path, base):
    path = safe_file(Path(path), Path(base))
    with path.open('rb') as f:
        raw = f.read(MAX_XML + 1)
    if len(raw) > MAX_XML:
        raise ValueError('XML exceeds 1 MiB')
    check = raw.replace(b'\x00', b'').upper()
    if b'<!DOCTYPE' in check or b'<!ENTITY' in check:
        raise ValueError('DTD/ENTITY rejected')
    return ET.fromstring(raw)


def get_ids(node):
    return [pid(item.text) for item in node.findall('li') if pid(item.text)] if node is not None else []


def get_dependencies(node):
    if node is None:
        return []
    result = []
    for item in node.findall('li'):
        result.append({'package_id': pid(item.findtext('packageId')),
                       'name': short(item.findtext('displayName'), 160),
                       'alternatives': get_ids(item.find('alternativePackageIds'))})
    return result


def selected_rules(root, field, version):
    selected = root.find(field)
    source = field
    versioned = root.find(field + 'ByVersion')
    if version and versioned is not None:
        for node in versioned:
            if node.tag.lower().removeprefix('v') == version:
                # Version-specific values replace the general list, including an empty list.
                selected, source = node, field + 'ByVersion/' + node.tag
                break
    return (get_dependencies(selected) if field == 'modDependencies' else get_ids(selected)), source


def read_profile(profile_root):
    result = {'available': False, 'active_ids': [], 'version': None, 'issues': []}
    if profile_root is None:
        result['issues'].append('Чтение профиля не разрешено в конфигурации клиента.')
        return result
    path = Path(profile_root) / 'Config' / 'ModsConfig.xml'
    result['path'] = str(path)
    if not path.exists():
        result['issues'].append('ModsConfig.xml не найден в разрешённой папке профиля.')
        return result
    try:
        root = read_xml(path, Path(profile_root))
        active = root.find('activeMods')
        if active is None:
            raise ValueError('No activeMods element')
        result.update(available=True, active_ids=get_ids(active), version=short(root.findtext('version'), 80),
                      modified_utc=utc(path.stat().st_mtime))
    except (OSError, ValueError, ET.ParseError) as exc:
        result['issues'].append(short(exc))
    return result


ERROR_PATTERN = re.compile(r'\b(?:error|exception|failed|failure)\b|Exception:|Could not (?:resolve|load|find)|duplicate.*def|Could not resolve cross-reference', re.I)


def read_logs(profile_root):
    blocks, files, game_versions = [], [], []
    if profile_root is None:
        return blocks, files, game_versions
    for name in ('Player.log', 'Player-prev.log'):
        path = Path(profile_root) / name
        info = {'file': name, 'exists': path.exists()}
        files.append(info)
        if not path.exists():
            continue
        try:
            path = safe_file(path, Path(profile_root))
            stat = path.stat()
            with path.open('rb') as f:
                head = f.read(2 * 1024 * 1024)
                tail = b''
                if stat.st_size > len(head):
                    f.seek(max(len(head), stat.st_size - 512 * 1024))
                    tail = f.read(512 * 1024)
            raw_parts = [head] + ([tail] if tail else [])
            info.update(bytes=stat.st_size, modified_utc=utc(stat.st_mtime),
                        sampled=stat.st_size > len(head) + len(tail), inspected_bytes=len(head) + len(tail))
            for value in re.findall(r'RimWorld\s+(\d+\.\d+[^\r\n]{0,80})', head[:65536].decode('utf-8', 'replace')):
                game_versions.append({'file': name, 'version': value.strip()})
            seen = {}
            for part_index, raw in enumerate(raw_parts):
                lines = raw.decode('utf-8-sig', 'replace').splitlines()
                for i, line in enumerate(lines):
                    stripped = line.strip()
                    if not stripped or stripped.startswith(('at ', 'Verse.Log:', 'UnityEngine.', '(Filename:', 'System.Threading.')):
                        continue
                    if not ERROR_PATTERN.search(stripped):
                        continue
                    key = re.sub(r'0x[0-9a-fA-F]+', '0x…', stripped)[:600]
                    key = re.sub(r'[0-9a-fA-F]{10,}', 'HEX…', key)
                    if key in seen:
                        seen[key]['occurrences_in_sample'] += 1
                        continue
                    if len(seen) >= 70:
                        info['error_groups_truncated'] = True
                        continue
                    block = {'file': name, 'part': 'head' if part_index == 0 else 'tail',
                             'line_in_part': i + 1, 'headline': stripped[:600],
                             'context': '\n'.join(lines[i:i + 11])[:2400], 'occurrences_in_sample': 1}
                    seen[key] = block
            blocks.extend(seen.values())
        except (OSError, ValueError) as exc:
            info['error'] = short(exc)
    return blocks, files, game_versions


def metadata(path, base, folder, source, version):
    root = read_xml(path, base)
    row = {'folder': folder, 'source': source, 'about': folder.rstrip('/') + '/About/About.xml',
           'name': short(root.findtext('name'), 200), 'package_id': pid(root.findtext('packageId')),
           'supported_versions': get_ids(root.find('supportedVersions')),
           'legacy_target_version': short(root.findtext('targetVersion'), 80),
           'mod_version': short(root.findtext('modVersion'), 100), 'url': short(root.findtext('url'), 600)}
    row['metadata_issues'] = []
    if root.tag != 'ModMetaData':
        row['metadata_issues'].append('Unexpected root tag: ' + str(root.tag))
    fields = Counter(child.tag for child in root)
    for field, count in fields.items():
        if count > 1:
            row['metadata_issues'].append(f'Duplicate field: {field} ({count})')
    for field in RULES:
        row[field], selected = selected_rules(root, field, version)
        row.setdefault('rule_sources', {})[field] = selected
    row['has_versioned_rules'] = any(root.find(f + 'ByVersion') is not None for f in RULES)
    if not version and row['has_versioned_rules']:
        row['metadata_issues'].append('Version-specific rules not selected: target game version unknown')
    description = root.find('description')
    text = ''.join(description.itertext()) if description is not None else ''
    row['compatibility_notes'] = []
    for match in re.finditer(r'incompatib|not compatible|несовмест|конфликт|conflict', text, re.I):
        row['compatibility_notes'].append(short(text[max(0, match.start() - 80):match.start() + 350], 430))
        if len(row['compatibility_notes']) >= 4:
            break
    load_file = Path(path).parent.parent / 'LoadFolders.xml'
    if load_file.exists():
        try:
            lf = read_xml(load_file, base)
            row['load_folders'] = {child.tag: [short(n.text, 160) for n in child.findall('li')] for child in lf}
        except (OSError, ValueError, ET.ParseError) as exc:
            row['metadata_issues'].append('LoadFolders.xml: ' + short(exc))
    return row


def discover(base, source, version, coverage):
    base = Path(base).resolve()
    if not base.is_dir():
        return []
    rows = []
    candidates = [base] if (base / 'About' / 'About.xml').is_file() else []
    if not candidates:
        with os.scandir(base) as entries:
            children = sorted(itertools.islice(entries, 5001), key=lambda e: e.name.lower())
        if len(children) > 5000:
            coverage['inventory_truncated'] = True
            children = children[:5000]
        for entry in children:
            if not entry.is_dir(follow_symlinks=False) or entry.name.startswith('.'):
                continue
            if len(candidates) >= MAX_MODS:
                coverage['inventory_truncated'] = True
                break
            child = Path(entry.path)
            if (child / 'About' / 'About.xml').is_file():
                candidates.append(child)
            else:
                coverage['folders_without_about_count'] = coverage.get('folders_without_about_count', 0) + 1
                if len(coverage['folders_without_about']) < 80:
                    coverage['folders_without_about'].append({'source': source, 'folder': entry.name})
    for directory in candidates:
        relative = directory.relative_to(base).as_posix()
        label = relative if source == 'mods' else '@game_data/' + relative
        if relative == '.':
            label = '.' if source == 'mods' else '@game_data'
        about = directory / 'About' / 'About.xml'
        try:
            rows.append(metadata(about, base, label, source, version))
        except (OSError, ValueError, ET.ParseError, RuntimeError) as exc:
            rows.append({'folder': label, 'source': source, 'about': label + '/About/About.xml',
                         'name': directory.name, 'package_id': '', 'parse_error': short(exc),
                         'supported_versions': [], 'metadata_issues': []})
    return rows


def analyze(rows, profile, version, coverage):
    findings = []
    def add(severity, code, mods, message, **details):
        if len(findings) >= MAX_FINDINGS:
            coverage['findings_truncated'] = True
            return
        findings.append({'severity': severity, 'code': code, 'mods': mods, 'message': message, **details})
    by_id = defaultdict(list)
    for row in rows:
        if row['package_id']:
            by_id[row['package_id']].append(row)
        if row.get('parse_error'):
            add('error', 'INVALID_METADATA_XML', [row['folder']], row['parse_error'], evidence=row['about'], scope='installed')
        elif not row['package_id']:
            add('warning', 'MISSING_PACKAGE_ID', [row['folder']], 'В About.xml не указан packageId.', evidence=row['about'], scope='installed')
        for problem in row.get('metadata_issues', []):
            add('warning', 'METADATA_WARNING', [row['package_id'] or row['folder']], problem, evidence=row['about'], scope='installed')
    for key, copies in by_id.items():
        if len(copies) > 1:
            add('warning', 'DUPLICATE_PACKAGE_ID', [key], 'Найдено несколько установленных копий одного packageId; выбранную игрой копию нужно уточнить.',
                folders=[r['folder'] for r in copies], scope='installed')
    active = []
    for position, raw in enumerate(profile['active_ids']):
        normalized, resolution = raw, 'exact'
        if normalized not in by_id:
            for suffix in ('_steam', '_copy', '_local'):
                if raw.endswith(suffix) and raw[:-len(suffix)] in by_id:
                    normalized, resolution = raw[:-len(suffix)], 'suffix'
                    break
        candidates = by_id.get(normalized, [])
        active.append({'position': position, 'raw_id': raw, 'package_id': normalized,
                       'name': candidates[0]['name'] if len(candidates) == 1 else None,
                       'folders': [r['folder'] for r in candidates], 'resolution': resolution,
                       'resolved': len(candidates) == 1 and resolution == 'exact'})
        if resolution == 'suffix':
            add('warning', 'ACTIVE_VARIANT_UNVERIFIED', [raw], 'Активный идентификатор имеет суффикс варианта; найден базовый packageId, но выбранную копию по этому скану подтвердить нельзя.', scope='active')
        if not candidates:
            add('warning', 'ACTIVE_MOD_OUTSIDE_SCAN', [raw], 'Активный мод не найден в просканированных папках; он может находиться в другом каталоге/Steam Workshop.', scope='active')
    active_ids = {r['package_id'] for r in active}
    positions = {r['package_id']: r['position'] for r in active}
    for key, count in Counter(r['package_id'] for r in active).items():
        if count > 1:
            add('warning', 'DUPLICATE_ACTIVE_ID', [key], 'packageId повторяется в активном списке.', count=count, scope='active')
    confirmed_active = {r['package_id'] for r in active if r['resolved']}
    pairs = set()
    for row in rows:
        key = row['package_id']
        if not key or row.get('parse_error'):
            continue
        is_active = (True if key in confirmed_active else None if key in active_ids else False) if profile['available'] else None
        row['active'] = is_active
        row['active_position'] = positions.get(key)
        if version and row['source'] == 'mods' and is_active:
            if not row['supported_versions']:
                add('warning', 'NO_SUPPORTED_VERSIONS', [key], 'В метаданных нет supportedVersions; работоспособность не определена.', evidence=row['about'], scope='active')
            elif version not in row['supported_versions']:
                add('warning', 'VERSION_NOT_DECLARED', [key], f'Поддержка RimWorld {version} не заявлена. Это предупреждение, не доказанный сбой.',
                    supported=row['supported_versions'], evidence=row['about'], scope='active')
        # Multiple installed copies can have different rules; avoid asserting which was loaded.
        if len(by_id[key]) > 1:
            continue
        if is_active:
            for dep in row.get('modDependencies', []):
                acceptable = [dep['package_id']] + (dep['alternatives'] if version is None or tuple(map(int, version.split('.'))) >= (1, 6) else [])
                acceptable = [p for p in acceptable if p]
                if acceptable and not any(p in active_ids for p in acceptable):
                    add('error', 'DEPENDENCY_NOT_ACTIVE', [key] + acceptable, 'В сохранённом активном списке нет обязательной зависимости или допустимой альтернативы.',
                        dependency_name=dep['name'], installed_candidates=[p for p in acceptable if p in by_id],
                        evidence=row['about'] + ':' + row['rule_sources']['modDependencies'], scope='active')
            for field in ('loadBefore', 'loadAfter', 'forceLoadBefore', 'forceLoadAfter'):
                before = 'Before' in field
                for target in row.get(field, []):
                    if target not in positions:
                        continue
                    wrong = positions[key] > positions[target] if before else positions[key] < positions[target]
                    if wrong:
                        add('error' if field.startswith('force') else 'warning', 'DECLARED_LOAD_ORDER', [key, target],
                            f'Нарушено правило {field}: {key} должен быть ' + ('раньше ' if before else 'позже ') + target + '.',
                            evidence=row['about'] + ':' + row['rule_sources'][field], positions=[positions[key], positions[target]], scope='active')
        for target in row.get('incompatibleWith', []):
            if target not in by_id and target not in active_ids:
                continue
            pair = tuple(sorted((key, target)))
            if pair in pairs:
                continue
            pairs.add(pair)
            both_active = profile['available'] and key in confirmed_active and target in confirmed_active
            add('error' if both_active else 'info', 'DECLARED_ACTIVE_CONFLICT' if both_active else 'DECLARED_INSTALLED_CONFLICT', list(pair),
                'Автор объявил эти моды несовместимыми.' + (' Оба включены в сохранённом списке.' if both_active else 'Одновременное включение не подтверждено; это не ошибка текущего запуска.'),
                evidence=row['about'] + ':' + row['rule_sources']['incompatibleWith'], scope='active' if both_active else 'installed')
    findings.sort(key=lambda f: {'error': 0, 'warning': 1, 'info': 2}[f['severity']])
    return active, findings


class RimWorldAudit:
    def __init__(self, tools):
        self.tools = tools
        self.reports = tools.backup_dir.parent / 'reports'

    def run(self, args):
        requested = args.get('game_version')
        if requested is not None and (not isinstance(requested, str) or not re.fullmatch(r'\d+\.\d+', requested)):
            raise ValueError('game_version: укажите major.minor, например 1.6, либо не передавайте параметр.')
        profile_root = getattr(self.tools, 'profile_root', None)
        profile = read_profile(profile_root)
        log_errors, log_files, log_versions = read_logs(profile_root)
        version = requested or minor(profile['version'])
        version_source = 'explicit_request' if requested else 'ModsConfig.xml' if version else 'unknown'
        if not version:
            version = next((minor(v['version']) for v in log_versions if v['file'] == 'Player.log'), None)
            if version:
                version_source = 'last Player.log'
        coverage = {'inventory_truncated': False, 'findings_truncated': False, 'folders_without_about': [],
                    'scope': ['Selected Mods root'], 'notes': [
                        'Сканируются только моды с About/About.xml непосредственно в выбранной папке или её дочерних каталогах.',
                        'Внешние каталоги Steam Workshop не обходятся автоматически.',
                        'Не проверены исполнение C#, пересечения Harmony-патчей, результаты XPath, все Def-ссылки, настройки модов и сохранения.',
                        'Нет декларации конфликта — не доказательство совместимости. Список из ModsConfig.xml может отличаться от последнего запуска.',
                    ]}
        rows = discover(self.tools.root, 'mods', version, coverage)
        if getattr(self.tools, 'allow_game_metadata', False) and self.tools.root.name.lower() == 'mods':
            data = self.tools.root.parent / 'Data'
            if data.is_dir():
                coverage['scope'].append('Adjacent Data/*/About/About.xml and LoadFolders.xml, read-only')
                rows += discover(data, 'game_data', version, coverage)
        if profile_root is not None:
            coverage['scope'].append('Standard/explicit RimWorld profile: ModsConfig.xml, Player.log, Player-prev.log only')
        active, findings = analyze(rows, profile, version, coverage)
        counts = Counter(f['severity'] for f in findings)
        summary = {'created_utc': utc(time.time()), 'target_version': version, 'version_source': version_source,
                   'mods_in_selected_folder': sum(r['source'] == 'mods' for r in rows),
                   'built_in_metadata_count': sum(r['source'] == 'game_data' for r in rows),
                   'active_list_available': profile['available'], 'active_mod_count': len(active),
                   'unresolved_active_count': sum(not r['resolved'] for r in active),
                   'findings_by_severity': dict(counts), 'log_error_groups': len(log_errors),
                   'profile_issues': profile['issues'], 'log_files': log_files, 'log_versions': log_versions,
                   'mod_files_changed': False, 'compatibility_proven': False}
        if version and any(minor(v['version']) != version for v in log_versions if v['file'] == 'Player.log'):
            coverage['notes'].append('Версия в Player.log отличается от выбранной версии анализа; сообщения журнала могут относиться к другому запуску.')
        report_id = uuid.uuid4().hex
        report = {'report_id': report_id, 'summary': summary, 'mods': rows, 'active_mods': active,
                  'findings': findings, 'log_errors': log_errors, 'coverage': coverage, 'profile': profile}
        self.reports.mkdir(parents=True, exist_ok=True)
        with (self.reports / (report_id + '.json')).open('x', encoding='utf-8') as f:
            json.dump(report, f, ensure_ascii=False)
        return {'report_id': report_id, 'summary': summary, 'coverage': coverage,
                'first_findings': findings[:15], 'next_step': 'Use audit_page to read mods, active_mods, findings and log_errors in bounded pages.'}

    def page(self, args):
        report_id = args.get('report_id')
        section = args.get('section', 'summary')
        if not isinstance(report_id, str) or not re.fullmatch('[0-9a-f]{32}', report_id):
            raise ValueError('Invalid report_id')
        if section not in {'summary', 'mods', 'active_mods', 'findings', 'log_errors', 'coverage', 'profile'}:
            raise ValueError('Invalid report section')
        offset, limit = args.get('offset', 0), args.get('limit', 20)
        if type(offset) is not int or offset < 0 or type(limit) is not int or not 1 <= limit <= 40:
            raise ValueError('offset >= 0; limit 1–40')
        path = safe_file(self.reports / (report_id + '.json'), self.reports)
        if path.stat().st_size > 32 * 1024 * 1024:
            raise ValueError('Report exceeds 32 MiB')
        with path.open(encoding='utf-8') as f:
            report = json.load(f)
        data = report[section]
        if not isinstance(data, list):
            return {'report_id': report_id, 'section': section, 'data': data}
        selected, size = [], 0
        for item in data[offset:offset + limit]:
            item_size = len(json.dumps(item, ensure_ascii=False).encode('utf-8'))
            if size + item_size > 100000:
                if not selected:
                    selected.append({'item_truncated': True, 'message': 'Item exceeds page byte limit; inspect its source separately.', 'folder': item.get('folder') if isinstance(item, dict) else None})
                break
            selected.append(item)
            size += item_size
        following = offset + len(selected)
        return {'report_id': report_id, 'section': section, 'total': len(data), 'offset': offset,
                'items': selected, 'next_offset': following if following < len(data) else None}
