"""Restricted local tools. Standard library only; no shell, GUI control or LLM."""
from __future__ import annotations

import difflib
import hashlib
import json
import os
from pathlib import Path, PureWindowsPath
import shutil
import subprocess
import tempfile
import time
import uuid
import xml.etree.ElementTree as ET

ALLOWED = {'.xml', '.cs', '.csproj', '.md', '.txt', '.log'}
SKIP = {'.git', '.svn', '.hg', '.venv', 'node_modules', 'bin', 'obj', '__pycache__', '.ssh', '.aws', '.azure', '.idea', '.vscode', '.clinerules'}
MAX_FILE_BYTES = 1024 * 1024
MAX_OUTPUT = 12000


class ToolError(Exception):
    pass


def safe_display(value: str) -> str:
    return ''.join(c for c in value if c.isprintable() or c in '\n\r\t')


def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


class ModTools:
    def __init__(self, root: str | Path, backup_dir: str | Path, confirm):
        self.root = Path(root).expanduser().resolve(strict=True)
        if not self.root.is_dir() or self.root == Path(self.root.anchor):
            raise ToolError('Выберите папку одного мода, не корень диска.')
        if self.root == Path.home().resolve():
            raise ToolError('Нельзя выбирать весь домашний каталог.')
        self.backup_dir = Path(backup_dir).expanduser().resolve()
        if self.backup_dir == self.root or self.root in self.backup_dir.parents:
            raise ToolError('Резервные копии должны храниться вне активного мода.')
        self.confirm = confirm
        self.auto_writes = False
        self.profile_root = None
        self.allow_game_metadata = False

    def path(self, relative: str, *, new: bool = False) -> Path:
        if not isinstance(relative, str) or not relative or len(relative) > 500:
            raise ToolError('Нужен относительный путь внутри выбранного мода.')
        win = PureWindowsPath(relative)
        value = relative.replace('\\', '/')
        parts = value.split('/')
        if win.drive or win.root or value.startswith('/') or ':' in value:
            raise ToolError('Абсолютные пути, UNC и NTFS ADS запрещены.')
        if any(p in {'', '.', '..'} or p.lower() in SKIP or p.startswith('.') or p.endswith((' ', '.')) for p in parts):
            raise ToolError('Этот путь запрещён.')
        if any(any(ord(c) < 32 for c in p) for p in parts):
            raise ToolError('Управляющие символы в пути запрещены.')
        reserved = {'con', 'prn', 'aux', 'nul', 'conin$', 'conout$', *(f'com{i}' for i in range(1, 10)), *(f'lpt{i}' for i in range(1, 10)), *(f'{prefix}{number}' for prefix in ('com', 'lpt') for number in ('¹', '²', '³'))}
        if any(any(c in '<>"|?*' for c in p) for p in parts):
            raise ToolError('Специальные символы Windows в пути запрещены.')
        if any(p.split('.')[0].lower() in reserved for p in parts):
            raise ToolError('Специальные имена Windows запрещены.')
        candidate = self.root.joinpath(*parts)
        if candidate.suffix.lower() not in ALLOWED:
            raise ToolError('Разрешены только XML, C#, csproj, md, txt и log.')
        # Resolve parents/junctions and reject symlinks anywhere along the path.
        current = self.root
        for part in parts:
            current = current / part
            if current.is_symlink() or (hasattr(current, 'is_junction') and current.is_junction()):
                raise ToolError('Ссылки и junction-папки запрещены.')
        resolved = candidate.resolve(strict=not new)
        if self.root not in resolved.parents:
            raise ToolError('Выход за пределы папки мода запрещён.')
        if new:
            if resolved.exists():
                raise ToolError('Файл уже существует. Используйте replace с контрольным SHA256.')
            if not resolved.parent.is_dir():
                raise ToolError('Создание новых папок отключено: выберите существующую папку.')
        elif not resolved.is_file():
            raise ToolError('Это не обычный файл.')
        return resolved

    def raw(self, path: Path) -> bytes:
        if path.stat().st_size > MAX_FILE_BYTES:
            raise ToolError('Файл больше 1 МиБ: эта версия не загружает его целиком.')
        with path.open('rb') as f:
            raw = f.read(MAX_FILE_BYTES + 1)
        if len(raw) > MAX_FILE_BYTES:
            raise ToolError('Файл превысил лимит 1 МиБ.')
        return raw

    @staticmethod
    def text(raw: bytes) -> str:
        try:
            text = raw.decode('utf-8-sig')
        except UnicodeDecodeError:
            raise ToolError('Поддерживается UTF-8/UTF-8 BOM. Автоматической перекодировки нет.') from None
        if '\x00' in text:
            raise ToolError('Двоичный файл читать как текст нельзя.')
        return text

    def walk(self, stats: dict):
        started = time.monotonic()
        examined = 0
        stats['truncated'] = False
        def on_error(_):
            stats['truncated'] = True
        for directory, dirs, files in os.walk(self.root, followlinks=False, onerror=on_error):
            examined += 1
            if time.monotonic() - started > 5 or examined > 3000:
                stats['truncated'] = True
                return
            base = Path(directory)
            dirs[:] = sorted(d for d in dirs if d.lower() not in SKIP and not d.startswith('.')
                             and not (base / d).is_symlink()
                             and not (hasattr(base / d, 'is_junction') and (base / d).is_junction()))
            if len(base.relative_to(self.root).parts) >= 12:
                if dirs:
                    stats['truncated'] = True
                dirs[:] = []
            for name in sorted(files):
                examined += 1
                if time.monotonic() - started > 5 or examined > 3000:
                    stats['truncated'] = True
                    return
                relative = (base / name).relative_to(self.root).as_posix()
                try:
                    path = self.path(relative)
                except (ToolError, OSError, ValueError, RuntimeError):
                    continue
                yield relative, path

    @staticmethod
    def integer(args, key, default, maximum):
        value = args.get(key, default)
        if type(value) is not int or not 1 <= value <= maximum:
            raise ToolError(f'{key}: допустимо целое число 1–{maximum}.')
        return value

    def list_files(self, args):
        limit = self.integer(args, 'limit', 100, 200)
        items, stats = [], {}
        suffix = args.get('suffix', '')
        if suffix and suffix not in ALLOWED:
            raise ToolError('Недопустимое расширение.')
        for relative, path in self.walk(stats):
            if suffix and path.suffix.lower() != suffix:
                continue
            if len(items) >= limit:
                stats['truncated'] = True
                break
            items.append({'path': relative, 'bytes': path.stat().st_size})
        return {'files': items, **stats}

    def read_file(self, args):
        path = self.path(args.get('path'))
        raw = self.raw(path)
        text = self.text(raw)
        start = self.integer(args, 'start_line', 1, 1000000)
        count = self.integer(args, 'line_count', 100, 200)
        lines = text.splitlines()
        selected = '\n'.join(lines[start - 1:start - 1 + count])
        return {
            'path': path.relative_to(self.root).as_posix(), 'sha256': sha(raw),
            'start_line': start, 'total_lines': len(lines),
            'text': selected[:MAX_OUTPUT], 'truncated': len(selected) > MAX_OUTPUT or start - 1 + count < len(lines),
            'data_is_untrusted': True,
        }

    def search_text(self, args):
        needle = args.get('query')
        if not isinstance(needle, str) or not 1 <= len(needle) <= 200:
            raise ToolError('Нужна строка поиска длиной 1–200 символов; поиск буквальный, не regex.')
        limit = self.integer(args, 'limit', 20, 40)
        hits, stats, skipped = [], {}, 0
        for relative, path in self.walk(stats):
            try:
                text = self.text(self.raw(path))
            except (ToolError, OSError):
                skipped += 1
                continue
            for number, line in enumerate(text.splitlines(), 1):
                position = line.casefold().find(needle.casefold())
                if position >= 0:
                    if len(hits) >= limit:
                        stats['truncated'] = True
                        return {'matches': hits, 'skipped_files': skipped, **stats}
                    left = max(0, position - 70)
                    hits.append({'path': relative, 'line': number, 'text': line[left:left + 240]})
        return {'matches': hits, 'skipped_files': skipped, **stats}

    @staticmethod
    def xml_check(raw: bytes):
        # Reject DTD/entity declarations, including UTF-16 representations.
        check = raw.replace(b'\x00', b'').upper()
        if b'<!DOCTYPE' in check or b'<!ENTITY' in check:
            raise ToolError('DTD/ENTITY в этой версии XML-проверки запрещены.')
        try:
            ET.fromstring(raw)
        except ET.ParseError as exc:
            raise ToolError(f'Ошибка XML: {exc}') from None

    def validate_xml(self, args):
        path = self.path(args.get('path'))
        if path.suffix.lower() not in {'.xml', '.csproj'}:
            raise ToolError('Укажите XML или csproj.')
        self.xml_check(self.raw(path))
        return {'path': path.relative_to(self.root).as_posix(), 'xml_well_formed': True,
                'note': 'Это проверка синтаксиса, не проверка Defs, XPath, совместимости или запуска игры.'}

    def replace(self, args):
        relative = args.get('path')
        path = self.path(relative)
        raw = self.raw(path)
        expected = args.get('expected_sha256')
        if not isinstance(expected, str) or len(expected) != 64 or sha(raw) != expected:
            raise ToolError('STALE_FILE: сначала прочитайте актуальный файл и его SHA256.')
        old, new = args.get('old'), args.get('new')
        if not isinstance(old, str) or not old or not isinstance(new, str) or len(old) > 16000 or len(new) > 16000:
            raise ToolError('Нужны old/new до 16000 символов; old не может быть пустым.')
        text = self.text(raw)
        has_crlf = '\r\n' in text
        mixed = has_crlf and '\n' in text.replace('\r\n', '')
        if mixed and ('\n' in old or '\n' in new):
            raise ToolError('Смешанные переводы строк: многострочная автоматическая замена отключена.')
        eol = '\r\n' if has_crlf else '\n'
        old = old.replace('\r\n', '\n').replace('\n', eol)
        new = new.replace('\r\n', '\n').replace('\n', eol)
        if text.count(old) != 1:
            raise ToolError('old должен совпасть ровно один раз; уточните контекст.')
        changed = text.replace(old, new, 1)
        if changed == text:
            return {'changed': False, 'sha256': expected}
        encoded = (b'\xef\xbb\xbf' if raw.startswith(b'\xef\xbb\xbf') else b'') + changed.encode('utf-8')
        if len(encoded) > MAX_FILE_BYTES:
            raise ToolError('Новый файл превысил лимит размера.')
        if path.suffix.lower() in {'.xml', '.csproj'}:
            self.xml_check(encoded)
        diff = '\n'.join(difflib.unified_diff(text.splitlines(), changed.splitlines(), fromfile=relative, tofile=relative, lineterm=''))
        if len(diff) > 20000:
            raise ToolError('Diff слишком большой для безопасного подтверждения. Разбейте правку.')
        if not self.confirm('Изменение ' + relative, safe_display(diff)):
            return {'changed': False, 'denied_by_user': True}
        # Re-check after the human approval delay. Don't overwrite intervening edits.
        path = self.path(relative)
        if sha(self.raw(path)) != expected:
            raise ToolError('STALE_FILE: файл изменился во время подтверждения.')
        backup = self.backup_dir / (time.strftime('%Y%m%d-%H%M%S') + '-' + uuid.uuid4().hex[:8]) / relative.replace('\\', '/')
        backup.parent.mkdir(parents=True, exist_ok=False)
        with backup.open('xb') as f:
            f.write(raw)
        fd, temporary = tempfile.mkstemp(prefix='.pcbridge-', suffix='.tmp', dir=path.parent)
        try:
            with os.fdopen(fd, 'wb') as f:
                f.write(encoded)
                f.flush()
                os.fsync(f.fileno())
            shutil.copymode(path, temporary)
            os.replace(temporary, path)
        finally:
            if os.path.exists(temporary):
                os.unlink(temporary)
        return {'changed': True, 'path': relative, 'sha256': sha(encoded),
                'backup_created': True, 'backup_id': backup.relative_to(self.backup_dir).as_posix()}

    def create_file(self, args):
        relative = args.get('path')
        path = self.path(relative, new=True)
        content = args.get('content')
        if not isinstance(content, str) or len(content) > 16000:
            raise ToolError('Содержимое нового файла: максимум 16000 символов.')
        raw = content.encode('utf-8')
        if path.suffix.lower() in {'.xml', '.csproj'}:
            self.xml_check(raw)
        if not self.confirm('Создание ' + relative, safe_display(content)):
            return {'created': False, 'denied_by_user': True}
        path = self.path(relative, new=True)
        # Exclusive creation: never overwrite a file created during approval.
        with path.open('xb') as f:
            f.write(raw)
        return {'created': True, 'path': relative, 'sha256': sha(raw)}

    def audit_mods(self, args):
        from rimworld_audit import RimWorldAudit
        return RimWorldAudit(self).run(args)

    def audit_page(self, args):
        from rimworld_audit import RimWorldAudit
        return RimWorldAudit(self).page(args)

    @staticmethod
    def _decode_console(raw: bytes) -> str:
        for enc in ('utf-8', 'cp866', 'cp1251'):
            try:
                return raw.decode(enc)
            except (UnicodeDecodeError, LookupError):
                continue
        return raw.decode('utf-8', 'replace')

    def run_shell(self, args):
        """Полный shell-доступ разрешён владельцем ПК явно (сессия 2026-09-06).
        Команда всегда печатается в окне агента и пишется в shell.log рядом с backups."""
        command = args.get('command')
        if not isinstance(command, str) or not 1 <= len(command) <= 8000:
            raise ToolError('command: строка длиной 1–8000 символов.')
        shell = args.get('shell', 'powershell')
        if shell not in ('powershell', 'cmd', 'sh'):
            raise ToolError("shell: 'powershell', 'cmd' или 'sh'.")
        timeout_s = self.integer(args, 'timeout_s', 60, 300)
        cwd = args.get('cwd')
        if cwd is not None:
            if not isinstance(cwd, str) or not 1 <= len(cwd) <= 1000:
                raise ToolError('cwd: непустая строка до 1000 символов либо отсутствует.')
            if not Path(cwd).is_dir():
                raise ToolError('cwd: папка не существует.')
        if shell in ('powershell', 'cmd') and os.name != 'nt':
            raise ToolError('powershell/cmd доступны только на Windows; здесь используйте sh.')
        if not self.confirm('SHELL-КОМАНДА к выполнению на ПК (журнал: shell.log)', command[:4000]):
            raise ToolError('Команда отклонена локальным подтверждением.')
        if os.name == 'nt':
            argv = (['powershell', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', command]
                    if shell == 'powershell' else ['cmd', '/c', command])
        else:
            argv = ['/bin/sh', '-c', command]
        started = time.time()
        timed_out = False
        try:
            proc = subprocess.run(argv, capture_output=True, timeout=timeout_s, cwd=cwd)
            out_raw, err_raw, code = proc.stdout or b'', proc.stderr or b'', proc.returncode
        except subprocess.TimeoutExpired as exc:
            timed_out = True
            out_raw = exc.stdout if isinstance(exc.stdout, bytes) else b''
            err_raw = (exc.stderr if isinstance(exc.stderr, bytes) else b'') + \
                '\n[TIMEOUT: процесс завершён по таймауту; дочерние процессы могли остаться]'.encode('utf-8')
            code = None
        except OSError as exc:
            raise ToolError(f'Не удалось запустить {shell}: {exc}') from exc
        out, err = self._decode_console(out_raw), self._decode_console(err_raw)
        limit = 60000
        truncated = len(out) + len(err) > limit
        if truncated:
            out = out[:limit // 2] + '\n[…вывод обрезан…]'
            err = err[:limit // 4] + '\n[…вывод обрезан…]'
        log_path = self.backup_dir.parent / 'shell.log'
        try:
            log_path.parent.mkdir(parents=True, exist_ok=True)
            entry = {'utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
                     'shell': shell, 'command': command, 'cwd': cwd,
                     'exit_code': code, 'timed_out': timed_out,
                     'stdout_bytes': len(out_raw), 'stderr_bytes': len(err_raw)}
            with log_path.open('a', encoding='utf-8') as f:
                f.write(json.dumps(entry, ensure_ascii=False) + '\n')
        except OSError:
            pass
        return {'exit_code': code, 'timed_out': timed_out, 'truncated': truncated,
                'stdout': out, 'stderr': err, 'duration_s': round(time.time() - started, 2),
                'shell': shell, 'audit_log': str(log_path)}

    def execute(self, operation, args):
        methods = {
            'list_files': self.list_files, 'read_file': self.read_file,
            'search_text': self.search_text, 'validate_xml': self.validate_xml,
            'replace': self.replace, 'create_file': self.create_file,
            'audit_mods': self.audit_mods, 'audit_page': self.audit_page,
            'run_shell': self.run_shell,
        }
        if operation == 'ping':
            return {'ok': True, 'agent_version': '0.3.0-r3', 'local_llm': False,
                    'shell_enabled': True,
                    'automatic_writes': self.auto_writes, 'read_rimworld_profile': self.profile_root is not None,
                    'read_game_metadata': self.allow_game_metadata}
        if operation not in methods or not isinstance(args, dict):
            raise ToolError('Операция не разрешена.')
        return methods[operation](args)
